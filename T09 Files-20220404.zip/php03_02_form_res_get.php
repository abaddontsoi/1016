<html>
	<body>

	Welcome <?php echo $_GET["fname"]; ?>.<br />
	You are <?php echo $_GET["age"]; ?> years old!
	
	</body>
</html>